$(document).ready(function(){
    $('.modal').modal(); //Das Login Pop-Up Fenster wird auf Knopfdruck geöffnet
  });

$.getJSON( "js/produkte.json", function( data ) { //Das JSON wird aufgerufen
  var items = [];
  $.each( data["produkte"]["gerichte"], function( key, val ) { //Die Dateien werden mit den Funktionen key und val versehen damit man sie nachfolgend aufrufen kann
    $("#card-template").clone().attr("id","gericht_"+key).appendTo("#kacheln").show(); //Es werden im HTML so viele Karten erstellt wie es Produkte gibt
	$("#gericht_"+key).find(".card-content p").html(val["description"]); //Die description ersetzt den Karten-FLießtext
	$("#gericht_"+key).find(".image").attr("src","img/products/"+val["image"]); //Das image ersetzt das Kartenbild
	$("#gericht_"+key).find(".card-title").html(val["name"]); //Der name ersetzt den Produkttitel auf den Karten
  });
 
});