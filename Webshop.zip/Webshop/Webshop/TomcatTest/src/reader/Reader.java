package reader;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import jdk.nashorn.api.scripting.JSObject;

public class Reader {
	private String filePath = "users.csv";

	public void getUsers(Map<String,String> users) throws IOException {
		try{
		FileReader fr = new FileReader(filePath);
		BufferedReader br = new BufferedReader(fr);

		 String line = null;
         while((line = br.readLine()) != null) {
             String[] parts = line.split(";");
             users.put(parts[0], parts[1]);
         }
         br.close();
		}catch(FileNotFoundException e){
			System.out.println("Datei wurde nicht gefunde "+ e.getMessage());
		}
		catch(IOException e){
			System.out.println("Es ist ein Fehler aufgetreten beim Lesen der Datei "+ e.getMessage());
		}
		
	}
}